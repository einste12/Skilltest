<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Campuses extends Model
{


    protected $guarded = [];

    protected $table = 'campuses';


}
